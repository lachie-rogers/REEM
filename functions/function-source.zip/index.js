const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);


const stripe = require('stripe')('sk_test_nZsu2bIFY7AO6Zes6Ltjjsgj000ujynqge')

exports.stripeCharge = functions.firestore
.document('Payments/{paymentId}')
.onWrite( (change,context) => {

const payment = change.after.data();
let paymentId = context.params.paymentId;

let payIdRef = admin.firestore().collection('Payments').doc(paymentId)

let payIdRef2 = admin.firestore().collection('Receipts').doc(paymentId)

if(!payment || payment.charge) return;

return payIdRef.get()
            .then(snapshot => {
                return snapshot.data();
            })
            .then(customer => {
                const amount = payment.Token.amount;
                const idempotencyKey = paymentId;
                const source = payment.Token.token.id;
                const currency = "aud";
                const charge = {amount, currency, source};

                return stripe.charges.create(charge, {idempotencyKey});
            })

            .then(charge => {
                payIdRef2
                .set(charge, {merge: true});
                return true;
                })
            })