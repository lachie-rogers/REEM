const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);




exports.Returns = functions.firestore
.document('Returns/{id}')
.onWrite( (change,context) => {


    let { id } = context.params;

    if (typeof id !== "string" ) {
      console.warn(`Invalid params, expected 'userId' and 'friendId'`, context.params);

      id = change.after.ref.parent.parent.id;
    }



console.log(id)

let payIdRef2 = admin.firestore().collection('Bookings').doc(id)

return payIdRef2.delete()
        
             })