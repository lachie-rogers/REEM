const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp(functions.config().firebase);




exports.stripeBooking = functions.firestore
.document('Receipts/{paymentId}')
.onWrite( (change,context) => {


let paymentId = context.params.paymentId;


let payIdRef3 = admin.firestore().collection('Payments').doc(paymentId)
let payIdRef2 = admin.firestore().collection('Bookings').doc(paymentId)

return payIdRef3.get("Token.amount")

.then(doc => {
    if (!doc.exists) {
      console.log('No such document!');
    } else {
      
    var doc1 = doc.data();

    console.log(doc.data());

    const Bookings = {
    User: doc1.Token.uid,
    Car: doc1.Token.car.id,
    Date: doc1.Token.value
    };
    payIdRef2.set(Bookings, {merge: true});
        return true;
    }
  })
        
             })